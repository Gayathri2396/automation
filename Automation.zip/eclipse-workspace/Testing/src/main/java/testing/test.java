package testing;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class test {

	WebDriver driver;
	
	@Test
	public void verifyTitle() throws InterruptedException
	{
	String actualTitle=driver.getTitle();
	String expectedTile="ELFINITY TECHNOLOGIES – CONNECTING YOU TO THE FUTURE";
	Assert.assertEquals(actualTitle, expectedTile);
	Thread.sleep(3000);
	driver.findElement(By.xpath("//a[contains(text(),'Get A Quote')]")).click();
	Thread.sleep(3000);
	
	}
	@AfterMethod
	public void tearDown()
	{
		
		driver.quit();
	}

}
