package Hooks;

import org.openqa.selenium.WebDriver;

public class DriverUtills {

	
	public static WebDriver driver;
	

}
