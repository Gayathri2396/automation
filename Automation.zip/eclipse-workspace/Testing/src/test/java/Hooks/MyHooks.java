package Hooks;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class MyHooks extends DriverUtills {
	
    
	@Before
	public void beforeScenario(Scenario scenario) throws Throwable {
		System.out.println("working");
		driver=new ChromeDriver();
		driver.get("https://www.amazon.in");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        Thread.sleep(5000);
	}


	
	@After
	public void afterScenario(Scenario scenario) {
		boolean failed=scenario.isFailed();
		System.out.println("is Failed"+failed);
		driver.quit();
 
}
}
