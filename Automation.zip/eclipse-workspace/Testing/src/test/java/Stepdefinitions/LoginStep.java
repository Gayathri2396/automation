package Stepdefinitions;





import Hooks.DriverUtills;
import UserActionsClass.UserActions;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class LoginStep extends DriverUtills{
	UserActions Ac= new UserActions() ;
	
	
	@Given("^user enter \"([^\"]*)\" in the field$")
	public void user_Enter_UserName(String name) throws Throwable {
	   System.out.println("User Enterd name");
	  Ac.search(name);
	}
	
	@Then("^User clik on search$")
	public void user_Click_On_Login() throws Throwable {
	   System.out.println("User Click On Login");
	  Ac.clicOnSearch();
	}
	@And("^user click on product")
	public void user_Click_On_profile() throws Throwable {
	   System.out.println("User Click On profile");
	  Ac.clicOnProduct();
	}
	@And("^user click on price$")
	public void user_Click_On_View_profile() throws Throwable {
	   System.out.println("User Click On view and profile");
	  Ac.clickOnPrice();
	}
	@And("^user click on add cart$")
	public void user_Click_On_Edit() throws Throwable {
	   System.out.println("User Click On edit");
	  Ac.clickOnAddCart();
	}
	@And("^User close the cart$")
	public void user_Click_On_Close() throws Throwable {
	   System.out.println("User click on sign in");
	  Ac.clickOnClose();
	}
	@And("^User click on sign in$")
	public void user_Click_On_save() throws Throwable {
	   System.out.println("User click on sign in");
	  Ac.clickOnsignIn();
	}
	@And("^user enter \"([^\"]*)\" in the filed area$")
	public void user_Enter_UserName_In(String name) throws Throwable {
	   System.out.println("User Enterd name");
	  Ac.userName(name);
	}
	@And("^User click on continue$")
	public void user_Click_On_continue() throws Throwable {
	   System.out.println("User click on sign in");
	  Ac.clickOnContinue();
	}
	@And("^User enter \"([^\"]*)\" in the text area$")
	public void user_Enter_password_In(String pass) throws Throwable {
	   System.out.println("User Enterd name");
	  Ac.password(pass);
	}
	@And("^user click on sign in button$")
	public void user_Click_On_signin() throws Throwable {
	   System.out.println("User click on sign in");
	  Ac.clickOnsignInButton();
	}
	@And("^user click on brand$")
	public void user_Click_On_Brand() throws Throwable {
	   System.out.println("User click on sign in");
	  Ac.clickBrand();
	}
	@And("^user verify Brand$")
	public void user_Verify_Brand() throws Throwable {
	   System.out.println("User click on sign in");
	  Ac.verifyBrand();
	}
	


	
	   
	
	
	



}
