package UserActionsClass;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import Hooks.DriverUtills;

public class UserActions extends DriverUtills {


	JavascriptExecutor js = (JavascriptExecutor) driver;
		
	

	
	public void search(String name) throws Throwable 
	{
	try 
	{
	driver.findElement(By.xpath("//*[@id='twotabsearchtextbox']")).sendKeys(name);
	Thread.sleep(3000);
	
	
	}
	catch (Exception e) {
		System.out.println("Unable to enter the user name");
		
	}
	}
	
	
	public void clicOnSearch() throws Throwable 
	{
		try {
		driver.findElement(By.xpath("//*[@id='nav-search-submit-button']")).click();
		Thread.sleep(3000);
		
		
	}
		catch (Exception e) {
			System.out.println("Unable to Click On the Button");
			
		}
	
	
	}
	public void clicOnProduct() throws Throwable 
	{
		try {
		driver.findElement(By.xpath("//div[@data-component-id='2']//a[@class='a-link-normal s-underline-text s-underline-link-text s-link-style a-text-normal']//span")).click();
		Thread.sleep(3000);
		
		
	}
		catch (Exception e) {
			System.out.println("Unable to Click On the Button");
			
			
		}
	
	
	}
	public void clickOnPrice() throws Throwable 
	{
		try {
			WebElement Price=driver.findElement(By.xpath("//*[@id='corePriceDisplay_desktop_feature_div']//span[@class='a-price-whole']"));
		Thread.sleep(1000);
		
		System.out.println(Price.getText());
	}
		catch (Exception e) {
			System.out.println("Unable to Click On the Button");
			
		}
	
	
	}
	public void clickOnAddCart() throws Throwable 
	{
		try {
			String winHandleBefore = driver.getWindowHandle();
			for(String winHandle : driver.getWindowHandles()){
			    driver.switchTo().window(winHandle);
			}


			driver.close();
			driver.switchTo().window(winHandleBefore);
			 Thread.sleep(3000);
			driver.get("https://www.amazon.in/Apple-iPhone-13-128GB-Blue/dp/B09G9BL5CP/ref=sr_1_1_sspa?crid=AMU8CVJURYHG&keywords=iphone&qid=1701829252&sprefix=%2Caps%2C272&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1");
			WebElement Element =driver.findElement(By.xpath("//*[@class='a-section price-update-feature-ww aok-hidden']//..//../div[@id='addToCart_feature_div']//input"));
		js.executeScript("arguments[0].scrollIntoView();", Element);
		Element.click();
		Thread.sleep(1000);
		
		
	}
		catch (Exception e) {
			System.out.println("Unable to Click On the Button");
			
		}
	
	
	}
	public void clickOnClose() throws Throwable 
	{
		try {
			WebElement Element =driver.findElement(By.xpath("//*[@id='attach-close_sideSheet-link']"));
			js.executeScript("arguments[0].scrollIntoView();", Element);
			Element.click();
		Thread.sleep(1000);
		
		
	}
		catch (Exception e) {
			System.out.println("Unable to Click On the Button");
			
		}
	
	
	}
	public void clickOnsignIn() throws Throwable 
	{
		try {
			WebElement Element =driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']"));
			js.executeScript("arguments[0].scrollIntoView();", Element);
			Element.click();
		Thread.sleep(1000);
		
		
	}
		catch (Exception e) {
			System.out.println("Unable to Click On the Button");
			
		}
	
	
	}
	public void userName(String Name) throws Throwable 
	{
		try {
			WebElement Element =driver.findElement(By.xpath("//*[@id='ap_email']"));
			js.executeScript("arguments[0].scrollIntoView();", Element);
			Element.sendKeys(Name);
		Thread.sleep(1000);
		
		
	}
		catch (Exception e) {
			System.out.println("Unable to Click On the Button");
			
		}

	

}
	public void clickOnContinue() throws Throwable 
	{
		try {
			WebElement Element =driver.findElement(By.xpath("//*[@class='a-button a-button-span12 a-button-primary']"));
			js.executeScript("arguments[0].scrollIntoView();", Element);
			Element.click();
		Thread.sleep(1000);
		
		
	}
		catch (Exception e) {
			System.out.println("Unable to Click On the Button");
			
		}
}
	public void password(String pass) throws Throwable 
	{
		try {
			WebElement Element =driver.findElement(By.xpath("//*[@id='ap_password']"));
			js.executeScript("arguments[0].scrollIntoView();", Element);
			Element.sendKeys(pass);
		Thread.sleep(1000);
		
		
	}
		catch (Exception e) {
			System.out.println("Unable to Click On the Button");
			
		}

	

}
	public void clickOnsignInButton() throws Throwable 
	{
		try {
			WebElement Element =driver.findElement(By.xpath("//*[@id='signInSubmit']"));
			js.executeScript("arguments[0].scrollIntoView();", Element);
			Element.click();
		Thread.sleep(1000);
		
		
	}
		catch (Exception e) {
			System.out.println("Unable to Click On the Button");
			
		}
}

public void clickBrand() throws Throwable 
{
	try {
		WebElement Element =driver.findElement(By.xpath("//*[@id='brandsRefinements']//span[contains(text(),'Apple')]"));
		js.executeScript("arguments[0].scrollIntoView();", Element);
		Element.click();
	Thread.sleep(1000);
	
	
}
	catch (Exception e) {
		System.out.println("Unable to Click On the Button");
		
	}
}
public void verifyBrand() throws InterruptedException
{
	WebElement actualTitle=driver.findElement(By.xpath("//*[@id='brandsRefinements']//span[contains(text(),'Apple')]"));
	actualTitle.getText();
String expectedTile="Apple";
Assert.assertEquals(actualTitle, expectedTile);
Thread.sleep(3000);

}
}
